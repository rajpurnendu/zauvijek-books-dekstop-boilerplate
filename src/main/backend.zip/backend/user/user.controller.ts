import UserService from './user.service'

const user = new UserService()

export { user }
