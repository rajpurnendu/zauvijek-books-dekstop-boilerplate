import Database from '../config/db'
import { Payment } from './payment.entity'

export default class PaymentService extends Database {
  constructor() {
    super()
    this.init()
    this.createPayment = this.createPayment.bind(this)
    this.getPayments = this.getPayments.bind(this)
    this.getPaymentById = this.getPaymentById.bind(this)
    this.updatePayment = this.updatePayment.bind(this)
    this.deletePayment = this.deletePayment.bind(this)
  }

  async createPayment(params: any): Promise<Payment[]> {
    const paymentRepository = this.dataSource.getRepository(Payment)
    const newPayment = paymentRepository.create(params)
    await paymentRepository.save(newPayment)
    return newPayment
  }

  public async getPayments(params: any): Promise<Payment[]> {
    const paymentRepository = this.dataSource.getRepository(Payment)
    const queryBuilder = paymentRepository.createQueryBuilder('payment')

    await queryBuilder
      .where('payment.business_id = :business_id', {
        business_id: params.business_id
      })
      .orderBy('payment.created_at', 'DESC')
      .getMany()

    const { entities } = await queryBuilder.getRawAndEntities()

    return entities
  }

  public async getPaymentById(id: string): Promise<Payment | unknown> {
    const paymentRepository = this.dataSource.getRepository(Payment)
    return await paymentRepository.findOneBy({ id })
  }

  public async updatePayment(id, params): Promise<Payment | unknown> {
    const paymentRepository = this.dataSource.getRepository(Payment)

    const updatedPayment = await paymentRepository.preload(params)

    if (updatedPayment === undefined) {
      throw new Error('Payment cannot be undefined')
    }

    await paymentRepository.save(updatedPayment)
    return await this.getPaymentById(id)
  }

  public async deletePayment(id): Promise<unknown> {
    const paymentRepository = this.dataSource.getRepository(Payment)
    return await paymentRepository.delete(id)
  }
}
