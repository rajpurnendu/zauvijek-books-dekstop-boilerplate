import PaymentService from './payment.service'

const payment = new PaymentService()

export { payment }
