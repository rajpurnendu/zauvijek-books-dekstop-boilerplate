import Database from '../../config/db'
import { BankCashCheque } from './bank_cash_cheque.entity'

export default class BankCashChequeService extends Database {
  constructor() {
    super()
    this.init()
    this.createBankCashCheque = this.createBankCashCheque.bind(this)
    this.getBankCashCheques = this.getBankCashCheques.bind(this)
    this.getBankCashChequeById = this.getBankCashChequeById.bind(this)
    this.updateBankCashCheque = this.updateBankCashCheque.bind(this)
    this.deleteBankCashCheque = this.deleteBankCashCheque.bind(this)
  }

  async createBankCashCheque(params: any): Promise<BankCashCheque[]> {
    const bankCashChequeRepository = this.dataSource.getRepository(BankCashCheque)
    const newBankCashCheque = bankCashChequeRepository.create(params)
    await bankCashChequeRepository.save(newBankCashCheque)
    return newBankCashCheque
  }

  public async getBankCashCheques(): Promise<BankCashCheque[]> {
    const bankCashChequeRepository = this.dataSource.getRepository(BankCashCheque)
    return await bankCashChequeRepository.find()
  }

  public async getBankCashChequeById(id): Promise<BankCashCheque | unknown> {
    const bankCashChequeRepository = this.dataSource.getRepository(BankCashCheque)
    return await bankCashChequeRepository.findOneBy({ id })
  }

  public async updateBankCashCheque(id, params): Promise<BankCashCheque | unknown> {
    const bankCashChequeRepository = this.dataSource.getRepository(BankCashCheque)

    const updatedBankCashCheque = await bankCashChequeRepository.preload(params)

    if (updatedBankCashCheque === undefined) {
      throw new Error('Bank Cash Cheque cannot be undefined')
    }

    await bankCashChequeRepository.save(updatedBankCashCheque)
    return await this.getBankCashChequeById(id)
  }

  public async deleteBankCashCheque(id): Promise<unknown> {
    const bankCashChequeRepository = this.dataSource.getRepository(BankCashCheque)
    return await bankCashChequeRepository.delete(id)
  }
}
