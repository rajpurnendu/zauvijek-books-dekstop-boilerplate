import BankCashChequeService from './bank_cash_cheque.service'

const bankCashCheque = new BankCashChequeService()

export { bankCashCheque }
