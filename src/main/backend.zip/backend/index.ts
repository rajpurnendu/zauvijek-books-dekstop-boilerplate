import { auth } from './authentication/authentication.controller'
import { user } from './user/user.controller'
import { item } from './inventory/item/item.controller'
import { sale } from './sale/sale/sale.controller'
import { purchase } from './purchase/purchase/purchase.controller'
import { payment } from './payment/payment.controller'
import { bankCashCheque } from './bank/bank_cash_cheque/bank_cash_cheque.controller'
import { expense } from './expense/expense/expense.controller'
import { getMachineIdSync } from './authentication/authentication.service'
export const services = {
  auth: auth,
  user: user,
  item: item,
  sale: sale,
  purchase: purchase,
  payment: payment,
  bankCashCheque: bankCashCheque,
  expense: expense,
  getMachineIdSync: getMachineIdSync
}
