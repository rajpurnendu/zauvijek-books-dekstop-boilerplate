import SaleService from './sale.service'

const sale = new SaleService()

export { sale }
