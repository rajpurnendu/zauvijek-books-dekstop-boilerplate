import Database from '../../config/db'
import { Sale } from './sale.entity'

export default class SaleService extends Database {
  constructor() {
    super()
    this.init()
    this.createSale = this.createSale.bind(this)
    this.getSales = this.getSales.bind(this)
    this.getSaleById = this.getSaleById.bind(this)
    this.updateSale = this.updateSale.bind(this)
    this.deleteSale = this.deleteSale.bind(this)
  }

  async createSale(params: any): Promise<Sale[]> {
    const saleRepository = this.dataSource.getRepository(Sale)
    const newSale = saleRepository.create(params)
    await saleRepository.save(newSale)
    return newSale
  }

  public async getSales(params: any): Promise<Sale[]> {
    const saleRepository = this.dataSource.getRepository(Sale)
    const queryBuilder = saleRepository.createQueryBuilder('sale')

    await queryBuilder
      .where('sale.business_id = :business_id', {
        business_id: params.business_id
      })
      .orderBy('sale.created_at', 'DESC')
      .getMany()

    const { entities } = await queryBuilder.getRawAndEntities()

    return entities
  }

  public async getSaleById(id: string): Promise<Sale | unknown> {
    const saleRepository = this.dataSource.getRepository(Sale)
    return await saleRepository.findOneBy({ id })
  }

  public async updateSale(id, params): Promise<Sale | unknown> {
    const saleRepository = this.dataSource.getRepository(Sale)

    const updatedSale = await saleRepository.preload(params)

    if (updatedSale === undefined) {
      throw new Error('Sale cannot be undefined')
    }

    await saleRepository.save(updatedSale)
    return await this.getSaleById(id)
  }

  public async deleteSale(id): Promise<unknown> {
    const saleRepository = this.dataSource.getRepository(Sale)
    return await saleRepository.delete(id)
  }
}
