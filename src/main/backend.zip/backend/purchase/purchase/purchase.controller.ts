import PurchaseService from './purchase.service'

const purchase = new PurchaseService()

export { purchase }
