import Database from '../../config/db'
import { Purchase } from './purchase.entity'

export default class PurchaseService extends Database {
  constructor() {
    super()
    this.init()
    this.createPurchase = this.createPurchase.bind(this)
    this.getPurchases = this.getPurchases.bind(this)
    this.getPurchaseById = this.getPurchaseById.bind(this)
    this.updatePurchase = this.updatePurchase.bind(this)
    this.deletePurchase = this.deletePurchase.bind(this)
  }

  async createPurchase(params: any): Promise<Purchase[]> {
    const purchaseRepository = this.dataSource.getRepository(Purchase)
    const newPurchase = purchaseRepository.create(params)
    await purchaseRepository.save(newPurchase)
    return newPurchase
  }

  public async getPurchases(params: any): Promise<Purchase[]> {
    const purchaseRepository = this.dataSource.getRepository(Purchase)
    const queryBuilder = purchaseRepository.createQueryBuilder('purchase')

    await queryBuilder
      .where('purchase.business_id = :business_id', {
        business_id: params.business_id
      })
      .orderBy('purchase.created_at', 'DESC')
      .getMany()

    const { entities } = await queryBuilder.getRawAndEntities()

    return entities
  }

  public async getPurchaseById(id: string): Promise<Purchase | unknown> {
    const purchaseRepository = this.dataSource.getRepository(Purchase)
    return await purchaseRepository.findOneBy({ id })
  }

  public async updatePurchase(id, params): Promise<Purchase | unknown> {
    const purchaseRepository = this.dataSource.getRepository(Purchase)

    const updatedPurchase = await purchaseRepository.preload(params)

    if (updatedPurchase === undefined) {
      throw new Error('Purchase cannot be undefined')
    }

    await purchaseRepository.save(updatedPurchase)
    return await this.getPurchaseById(id)
  }

  public async deletePurchase(id): Promise<unknown> {
    const purchaseRepository = this.dataSource.getRepository(Purchase)
    return await purchaseRepository.delete(id)
  }
}
