import ExpenseService from './expense.service'

const expense = new ExpenseService()

export { expense }
