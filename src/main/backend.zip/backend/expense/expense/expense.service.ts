import Database from '../../config/db'
import { Expense } from './expense.entity'

export default class ExpenseService extends Database {
  constructor() {
    super()
    this.init()
    this.createExpense = this.createExpense.bind(this)
    this.getExpenses = this.getExpenses.bind(this)
    this.getExpenseById = this.getExpenseById.bind(this)
    this.updateExpense = this.updateExpense.bind(this)
    this.deleteExpense = this.deleteExpense.bind(this)
  }

  async createExpense(params: any): Promise<Expense[]> {
    const expenseRepository = this.dataSource.getRepository(Expense)
    const newExpense = expenseRepository.create(params)
    await expenseRepository.save(newExpense)
    return newExpense
  }

  public async getExpenses(params: any): Promise<Expense[]> {
    const itemRepository = this.dataSource.getRepository(Expense)
    const queryBuilder = itemRepository.createQueryBuilder('expense')

    await queryBuilder
      .leftJoinAndSelect('expense.expense', 'expense_item')
      .where('expense.business_id = :business_id', {
        business_id: params.business_id
      })
      .orderBy('expense.created_at', 'DESC')
      .getMany()

    const { entities } = await queryBuilder.getRawAndEntities()

    return entities
  }

  public async getExpenseById(id: string): Promise<Expense | unknown> {
    const expenseRepository = this.dataSource.getRepository(Expense)
    return await expenseRepository.findOneBy({ id })
  }

  public async updateExpense(id, params): Promise<Expense | unknown> {
    const expenseRepository = this.dataSource.getRepository(Expense)

    const updatedExpense = await expenseRepository.preload(params)

    if (updatedExpense === undefined) {
      throw new Error('Expense cannot be undefined')
    }

    await expenseRepository.save(updatedExpense)
    return await this.getExpenseById(id)
  }

  public async deleteExpense(id): Promise<unknown> {
    const expenseRepository = this.dataSource.getRepository(Expense)
    return await expenseRepository.delete(id)
  }
}
