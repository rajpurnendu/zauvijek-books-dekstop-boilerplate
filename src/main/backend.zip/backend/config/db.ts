import 'reflect-metadata'
import path from 'node:path'
import { app } from '@electron/remote'
import { DataSource } from 'typeorm'

const dbPathProd: string = path.join(app.getPath('userData'), 'zauvijek.db')

// const dbPathDev: string = path.join(__dirname, 'zauvijek.db')

export default class Database {
  public dataSource: DataSource

  constructor() {
    this.init()
  }

  public async init(): Promise<void> {
    this.dataSource = new DataSource({
      type: 'sqlite',
      database: dbPathProd,
      synchronize: true,
      logging: false,
      entities: [],
      migrations: ['./migrations/*{.ts,.js}'],
      migrationsRun: false,
      subscribers: []
    })

    if (this.dataSource.isInitialized) {
      this.dataSource.synchronize()
    } else {
      this.dataSource.initialize()
    }
  }
}
