import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  ManyToOne
} from 'typeorm'
import { Item } from '../item/item.entity'

@Entity()
export class ItemBatching {
  @PrimaryGeneratedColumn('uuid')
  item_batching_id: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'batch_no'
  })
  batch_no: string

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    name: 'manufacture_date'
  })
  manufacture_date: Date

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    name: 'expiry_date'
  })
  expiry_date: Date

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'selling_price'
  })
  selling_price: number

  @Column({
    type: 'varchar',
    length: 64,
    default: 'without_tax',
    name: 'selling_price_type'
  })
  selling_price_type: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'purchase_price'
  })
  purchase_price: number

  @Column({
    type: 'varchar',
    length: 64,
    default: 'without_tax',
    name: 'purchase_price_type'
  })
  purchase_price_type: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'mrp'
  })
  mrp: number

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'unit'
  })
  unit: string

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_second_unit_enabled'
  })
  is_second_unit_enabled: boolean

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'second_unit'
  })
  second_unit: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'conversion_rate'
  })
  conversion_rate: number

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'opening_stock'
  })
  opening_stock: number

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    name: 'opening_stock_date'
  })
  opening_stock_date: Date

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'closing_stock'
  })
  closing_stock: number

  @ManyToOne(() => Item, (item) => item.item_batching, {
    onUpdate: 'CASCADE',
    onDelete: 'CASCADE'
  })
  @JoinColumn({ name: 'item_id' })
  item: Item

  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)'
  })
  created_at: Date

  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)'
  })
  updated_at: Date
}
