import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  ManyToOne
} from 'typeorm'
import { Item } from '../item/item.entity'

@Entity()
export class ItemSerialisation {
  @PrimaryGeneratedColumn('uuid')
  item_serialisation_id: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'serial_no'
  })
  serial_no: string

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    name: 'serial_no_date'
  })
  serial_no_date: Date

  @Column({
    type: 'boolean',
    default: true,
    name: 'is_available'
  })
  is_available: boolean

  @ManyToOne(() => Item, (item) => item.item_serialisation, {
    onUpdate: 'CASCADE',
    onDelete: 'CASCADE'
  })
  @JoinColumn({ name: 'item_id' })
  item: Item

  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)'
  })
  created_at: Date

  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)'
  })
  updated_at: Date
}
