import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany
} from 'typeorm'

import { ItemBatching } from '../item_batching/item_batching.entity'
import { ItemSerialisation } from '../item_serialisation/item_serialisation.entity'

@Entity()
export class Item {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({
    type: 'uuid',
    nullable: true,
    name: 'business_id'
  })
  business_id: string

  @Column({
    type: 'uuid',
    nullable: true,
    name: 'godown_warehouse_id'
  })
  godown_warehouse_id

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'item_type'
  })
  item_type: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'item_category'
  })
  item_category: string

  @Column({
    type: 'varchar',
    length: 512,
    nullable: true,
    name: 'item_name'
  })
  item_name: string

  @Column({
    type: 'text',
    nullable: true,
    name: 'item_description'
  })
  item_description: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'item_code'
  })
  item_code: string

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_mrp_enabled'
  })
  is_mrp_enabled: boolean

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_wholesale_enabled'
  })
  is_wholesale_enabled: boolean

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_serialisation_enabled'
  })
  is_serialisation_enabled: boolean

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_batching_enabled'
  })
  is_batching_enabled: boolean

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'selling_price'
  })
  selling_price: number

  @Column({
    type: 'varchar',
    length: 64,
    default: 'without_tax',
    name: 'selling_price_type'
  })
  selling_price_type: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'purchase_price'
  })
  purchase_price: number

  @Column({
    type: 'varchar',
    length: 64,
    default: 'without_tax',
    name: 'purchase_price_type'
  })
  purchase_price_type: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'mrp'
  })
  mrp: number

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'wholesale_price'
  })
  wholesale_price: number

  @Column({
    type: 'varchar',
    length: 64,
    default: 'without_tax',
    name: 'wholesale_price_type'
  })
  wholesale_price_type: string

  @Column({
    type: 'int',
    default: 0,
    nullable: true,
    name: 'wholesale_quantity'
  })
  wholesale_quantity: string

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'discount_percent'
  })
  discount_percent: number

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'discount_amount'
  })
  discount_amount: number

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'hsn_code'
  })
  hsn_code: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'sac_code'
  })
  sac_code: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'tax'
  })
  tax: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'cess'
  })
  cess: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'unit'
  })
  unit: string

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_second_unit_enabled'
  })
  is_second_unit_enabled: boolean

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'conversion_rate'
  })
  conversion_rate: number

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'opening_stock'
  })
  opening_stock: number

  @Column({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    name: 'opening_stock_date'
  })
  opening_stock_date: Date

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'closing_stock'
  })
  closing_stock: number

  @Column({
    type: 'boolean',
    default: false,
    name: 'is_min_stock_alert_enabled'
  })
  is_min_stock_alert_enabled: boolean

  @Column({
    type: 'decimal',
    precision: 12,
    scale: 2,
    default: 0,
    transformer: {
      to(value) {
        return value
      },
      from(value) {
        return parseFloat(value)
      }
    },
    name: 'min_stock_count'
  })
  min_stock_count: number

  @Column({
    type: 'text',
    nullable: true,
    name: 'item_image'
  })
  item_image: string

  @Column({
    type: 'varchar',
    length: 128,
    nullable: true,
    name: 'serial_no_label'
  })
  serial_no_label: string

  @OneToMany(() => ItemSerialisation, (item_serialisation) => item_serialisation.item, {
    cascade: true
  })
  item_serialisation: ItemSerialisation[]

  @OneToMany(() => ItemBatching, (item_batching) => item_batching.item, {
    cascade: true
  })
  item_batching: ItemBatching[]

  @CreateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)'
  })
  created_at: Date

  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP(6)',
    onUpdate: 'CURRENT_TIMESTAMP(6)'
  })
  updated_at: Date
}
