import ItemService from './item.service'

const item = new ItemService()

export { item }
