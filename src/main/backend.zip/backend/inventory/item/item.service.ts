import Database from '../../config/db'
import { Item } from './item.entity'

export default class ItemService extends Database {
  constructor() {
    super()
    this.init()
    this.createItem = this.createItem.bind(this)
    this.getItems = this.getItems.bind(this)
    this.getItemById = this.getItemById.bind(this)
    this.updateItem = this.updateItem.bind(this)
    this.deleteItem = this.deleteItem.bind(this)
  }

  async createItem(params: any): Promise<Item[]> {
    const itemRepository = this.dataSource.getRepository(Item)
    const newItem = itemRepository.create(params)
    await itemRepository.save(newItem)
    return newItem
  }

  public async getItems(params: any): Promise<Item[]> {
    const itemRepository = this.dataSource.getRepository(Item)
    const queryBuilder = itemRepository.createQueryBuilder('item')

    await queryBuilder
      .leftJoinAndSelect('item.item_serialisation', 'item_serialisation')
      .leftJoinAndSelect('item.item_batching', 'item_batching')
      .where('item.business_id = :business_id', {
        business_id: params.business_id
      })
      .orderBy('item.created_at', 'DESC')
      .getMany()

    const { entities } = await queryBuilder.getRawAndEntities()

    return entities
  }

  public async getItemById(id: string): Promise<Item | unknown> {
    const itemRepository = this.dataSource.getRepository(Item)
    return await itemRepository.findOneBy({ id })
  }

  public async updateItem(id, params): Promise<Item | unknown> {
    const itemRepository = this.dataSource.getRepository(Item)

    const updatedItem = await itemRepository.preload(params)

    if (updatedItem === undefined) {
      throw new Error('Item cannot be undefined')
    }

    await itemRepository.save(updatedItem)
    return await this.getItemById(id)
  }

  public async deleteItem(id): Promise<unknown> {
    const itemRepository = this.dataSource.getRepository(Item)
    return await itemRepository.delete(id)
  }
}
