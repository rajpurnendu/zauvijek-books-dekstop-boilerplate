import Database from '../../config/db'

export default class TransactionReportService extends Database {
  constructor() {
    super()
    this.init()
  }
}
