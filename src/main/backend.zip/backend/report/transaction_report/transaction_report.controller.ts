import TransactionReportService from './transaction_report.service'

const transactionReport = new TransactionReportService()

export { transactionReport }
