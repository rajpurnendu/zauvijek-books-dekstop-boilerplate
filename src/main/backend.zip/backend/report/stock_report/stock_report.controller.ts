import StockReportService from './stock_report.service'

const stockReport = new StockReportService()

export { stockReport }
