import PartyReportService from './party_report.service'

const partyReport = new PartyReportService()

export { partyReport }
