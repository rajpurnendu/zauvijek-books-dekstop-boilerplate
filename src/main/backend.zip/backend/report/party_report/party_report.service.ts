import Database from '../../config/db'

export default class PartyReportService extends Database {
  constructor() {
    super()
    this.init()
  }
}
