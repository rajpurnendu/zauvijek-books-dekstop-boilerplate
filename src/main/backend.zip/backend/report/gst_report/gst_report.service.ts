import Database from '../../config/db'

export default class GstReportService extends Database {
  constructor() {
    super()
    this.init()
  }
}
