import GstReportService from './gst_report.service'

const gstReport = new GstReportService()

export { gstReport }
