import Database from '../../config/db'

export default class ExpenseReportService extends Database {
  constructor() {
    super()
    this.init()
  }
}
