import ExpenseReportService from './expense_report.service'

const expenseReport = new ExpenseReportService()

export { expenseReport }
