import AuthService from './authentication.service'

const auth = new AuthService()

export { auth }
